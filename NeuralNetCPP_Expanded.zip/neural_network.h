#ifndef NEURAL_NETWORK_H
#define NEURAL_NETWORK_H

#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "utils.h"

class NeuralNetwork {
public:
    NeuralNetwork(const std::vector<int>& layers);
    std::vector<double> forward(const std::vector<double>& input);

private:
    std::vector<std::vector<std::vector<double>>> weights;
    std::vector<std::vector<double>> biases;
    std::vector<int> layers;

    std::vector<double> activate(const std::vector<double>& input, const std::vector<std::vector<double>>& weightMatrix, const std::vector<double>& biasVector);
};

#endif