#include "neural_network.h"

int main() {
    NeuralNetwork nn({3, 4, 1});  // 3 input, 4 hidden, 1 output
    std::vector<double> input = {0.5, 0.8, 0.3};
    std::vector<double> output = nn.forward(input);

    std::cout << "Output: ";
    print_vector(output);

    return 0;
}