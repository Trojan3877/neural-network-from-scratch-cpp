#include "utils.h"
#include <cmath>
#include <iostream>

double sigmoid(double x) {
    return 1.0 / (1.0 + std::exp(-x));
}

double sigmoid_derivative(double x) {
    double s = sigmoid(x);
    return s * (1 - s);
}

void print_vector(const std::vector<double>& vec) {
    for (double v : vec) {
        std::cout << v << " ";
    }
    std::cout << std::endl;
}