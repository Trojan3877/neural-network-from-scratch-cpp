#include "neural_network.h"

NeuralNetwork::NeuralNetwork(const std::vector<int>& layers) : layers(layers) {
    std::srand(std::time(nullptr));
    for (size_t i = 1; i < layers.size(); ++i) {
        std::vector<std::vector<double>> layerWeights;
        std::vector<double> layerBiases;

        for (int j = 0; j < layers[i]; ++j) {
            std::vector<double> neuronWeights;
            for (int k = 0; k < layers[i - 1]; ++k) {
                neuronWeights.push_back(((double) std::rand() / RAND_MAX) * 2 - 1);
            }
            layerWeights.push_back(neuronWeights);
            layerBiases.push_back(((double) std::rand() / RAND_MAX) * 2 - 1);
        }
        weights.push_back(layerWeights);
        biases.push_back(layerBiases);
    }
}

std::vector<double> NeuralNetwork::forward(const std::vector<double>& input) {
    std::vector<double> activation = input;

    for (size_t i = 0; i < weights.size(); ++i) {
        activation = activate(activation, weights[i], biases[i]);
    }
    return activation;
}

std::vector<double> NeuralNetwork::activate(const std::vector<double>& input, const std::vector<std::vector<double>>& weightMatrix, const std::vector<double>& biasVector) {
    std::vector<double> output;
    for (size_t i = 0; i < weightMatrix.size(); ++i) {
        double sum = biasVector[i];
        for (size_t j = 0; j < input.size(); ++j) {
            sum += weightMatrix[i][j] * input[j];
        }
        output.push_back(sigmoid(sum));
    }
    return output;
}