# NeuralNetCPP (Expanded Version)

This project builds a simple fully-connected neural network from scratch in C++.

## Files

- `main.cpp`: Entry point using a 3-4-1 neural network.
- `utils.*`: Activation functions and helpers.
- `neural_network.*`: Forward pass with layers and weights.

## Build

```bash
g++ main.cpp neural_network.cpp utils.cpp -o neural_net
./neural_net
```

## Next Steps

- Add backpropagation
- Add training with labeled data
- Use data.csv as input