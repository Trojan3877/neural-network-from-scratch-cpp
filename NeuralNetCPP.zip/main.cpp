#include "utils.h"

int main() {
    std::vector<double> input = {0.5, 0.8, 0.3};
    std::vector<double> activated;

    for (double x : input) {
        activated.push_back(sigmoid(x));
    }

    std::cout << "Sigmoid values: ";
    print_vector(activated);

    return 0;
}