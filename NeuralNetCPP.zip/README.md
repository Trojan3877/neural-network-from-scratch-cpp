# NeuralNetCPP

A simple neural network project built from scratch in C++.

## Files

- `main.cpp`: Entry point to test activation functions.
- `utils.h/cpp`: Contains sigmoid function and vector printing.
- Add your own training loop and layers to extend.

## Build

Compile with:

```bash
g++ main.cpp utils.cpp -o neural_net
./neural_net
```