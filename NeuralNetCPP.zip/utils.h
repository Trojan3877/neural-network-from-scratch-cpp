#ifndef UTILS_H
#define UTILS_H

#include <vector>

double sigmoid(double x);
double sigmoid_derivative(double x);
void print_vector(const std::vector<double>& vec);

#endif